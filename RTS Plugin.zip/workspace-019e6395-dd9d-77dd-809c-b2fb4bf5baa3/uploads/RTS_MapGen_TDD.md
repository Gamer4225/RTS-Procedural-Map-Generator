# RTS Procedural Battlefield Generator — Full Technical Design Document
**Version:** 1.0 | **Engine:** Unreal Engine 5.3+  
**Author:** Internal Design Document  
**Target Platform:** Fab Marketplace — Code Plugin  

---

## ⚠️ WHERE YOUR CURRENT PLAN IS WRONG (AND HOW TO FIX IT)

Before architecture, these are the critical errors to correct:

| ❌ Wrong Assumption | ✅ Correct Approach | Why |
|---|---|---|
| "Build everything before selling" | Ship MVP V1, sell early, patch fast | Cash flow funds development; early reviews build reputation |
| "Runtime generation first" | Editor-time generation ONLY for V1 | Runtime generation is 3–4× harder; determinism is brutal |
| "$500+ pricing from day one" | Start at $149–$199, raise with updates | Unknown sellers with no reviews cannot command $500; build rep first |
| "Blueprints for core logic" | C++ for ALL algorithms, Blueprint exposure only for configs | Blueprint loops on 10k+ cells will freeze the editor |
| "Voxel or hybrid terrain first" | Heightmap + Strategic Grid only for V1 | Voxels require 5× more engineering; add later |
| "Build visualization first" | Build DATA systems first, visualization last | Visualization exposes data; it cannot define it |
| "Full AI simulation in V1" | A* + Flow Fields + Heatmaps only for V1 | Monte Carlo simulation is a V3 feature minimum |
| "PCG Framework integration" | Do NOT depend on PCG for V1 | PCG API changes every UE minor version; wrap it later |
| "Single monolithic module" | Runtime Module + Editor Module (separate) | Editor code CANNOT ship in runtime builds — this crashes certification |

---

## PART 1 — PLUGIN IDENTITY & MARKET POSITION

### Product Name
**RTSMapForge** — *Strategic Battlefield Generator for Unreal Engine 5*

### What It Actually Is
Not a terrain generator. Not a landscape tool. It is:
> **An automated RTS map designer that generates strategically valid, gameplay-balanced battlefields with metadata AI systems can read.**

### Market Gap (From Competitor Research)
The RTSUnitTemplate (your reference) handles units, combat, and AI behaviors. It has **no map generation system**. That is your gap. Studios buying that plugin have no solution for generating the maps those units fight on.

**Target customers in priority order:**
1. Indie RTS developers (no budget for a level designer)
2. Studios using RTSUnitTemplate who need maps
3. Tactical/MOBA studios needing procedural layouts
4. Jam developers needing fast battlefield generation

---

## PART 2 — MODULE ARCHITECTURE

### Plugin Folder Structure
```
RTSMapForge/
├── RTSMapForge.uplugin
├── Source/
│   ├── RTSMapForgeRuntime/          ← Ships with games
│   │   ├── RTSMapForgeRuntime.Build.cs
│   │   ├── Public/
│   │   │   ├── Core/
│   │   │   │   ├── FRTSGrid.h
│   │   │   │   ├── FRTSCell.h
│   │   │   │   ├── FRTSSeedManager.h
│   │   │   │   └── URTSGenerationSettings.h
│   │   │   ├── Terrain/
│   │   │   │   ├── FRTSNoiseGenerator.h
│   │   │   │   ├── FRTSHeightmapGenerator.h
│   │   │   │   ├── FRTSBiomeAssigner.h
│   │   │   │   └── FRTSRiverGenerator.h
│   │   │   ├── Strategic/
│   │   │   │   ├── FRTSBasePlacer.h
│   │   │   │   ├── FRTSExpansionPlacer.h
│   │   │   │   ├── FRTSChokeDetector.h
│   │   │   │   ├── FRTSTacticalZoneClassifier.h
│   │   │   │   └── FRTSInfluenceMap.h
│   │   │   ├── Pathfinding/
│   │   │   │   ├── FRTSAStarSolver.h
│   │   │   │   ├── FRTSFlowField.h
│   │   │   │   └── FRTSNavigationGraph.h
│   │   │   ├── Analysis/
│   │   │   │   ├── FRTSStrategicScorer.h
│   │   │   │   ├── FRTSHeatmapSystem.h
│   │   │   │   └── FRTSFairnessAnalyzer.h
│   │   │   ├── Validation/
│   │   │   │   ├── FRTSValidationPipeline.h
│   │   │   │   └── FRTSValidationResult.h
│   │   │   └── Data/
│   │   │       ├── URTSBiomeAsset.h
│   │   │       ├── URTSGenerationPreset.h
│   │   │       └── FRTSMapMetadata.h
│   │   └── Private/
│   │       └── [.cpp implementations]
│   │
│   └── RTSMapForgeEditor/           ← Editor only, NOT shipped
│       ├── RTSMapForgeEditor.Build.cs
│       ├── Public/
│       │   ├── RTSMapForgeEditorModule.h
│       │   ├── SRTSMapGeneratorWindow.h   ← Slate UI
│       │   ├── FRTSEditorOverlayRenderer.h
│       │   ├── FRTSMinimapPreview.h
│       │   └── FRTSHeatmapOverlay.h
│       └── Private/
│           └── [.cpp implementations]
│
├── Content/
│   ├── Biomes/                      ← Default Data Assets
│   ├── Presets/                     ← Default presets
│   └── Materials/                   ← Debug overlay materials
│
└── Docs/
    ├── QuickStart.md
    └── API.md
```

### Module Type Declarations
```cpp
// RTSMapForgeRuntime.Build.cs
PublicDependencyModuleNames.AddRange(new string[] {
    "Core", "CoreUObject", "Engine",
    "NavigationSystem", "AIModule"
});

// RTSMapForgeEditor.Build.cs  
PublicDependencyModuleNames.AddRange(new string[] {
    "RTSMapForgeRuntime", "Core", "CoreUObject", "Engine",
    "UnrealEd", "Slate", "SlateCore", "EditorStyle",
    "LevelEditor", "PropertyEditor", "EditorFramework"
});
```

---

## PART 3 — CORE DATA STRUCTURES

These are your most important decisions. Everything else depends on these.

### FRTSCell — The Atomic Unit
```cpp
// Every cell on the map stores this
struct FRTSCell
{
    // === SPATIAL ===
    FVector2D   GridCoord;          // (X, Y) grid position
    FVector     WorldPosition;       // 3D world location
    float       Height;              // 0.0 - 1.0 normalized
    float       Slope;               // radians from flat

    // === TRAVERSAL ===
    float       MovementCostMultiplier; // 1.0 = normal, 2.0 = slow, 0.0 = blocked
    bool        bWalkable;
    bool        bBuildable;
    bool        bWater;
    bool        bCliff;

    // === GAMEPLAY ===
    float       CoverValue;          // 0.0 - 1.0
    float       VisibilityScore;     // 0.0 - 1.0 (how well you see FROM here)
    float       ExposureScore;       // 0.0 - 1.0 (how visible you are HERE)

    // === STRATEGIC ===
    float       StrategicValue;      // computed by StrategicScorer
    float       ResourceValue;       // resource richness
    float       ControlValue;        // influence map output
    ERTSTacticalZone TacticalZone;   // classified zone type

    // === REGION / BIOME ===
    int32       RegionID;            // flood-fill region index
    int32       BiomeID;             // biome index
    int32       ChunkID;             // spatial chunk for streaming

    // === NAVIGATION ===
    TArray<int32> NeighborIndices;   // flat index into Grid array
};
```

### ERTSTacticalZone — Zone Classification Enum
```cpp
UENUM(BlueprintType)
enum class ERTSTacticalZone : uint8
{
    Unclassified    UMETA(DisplayName = "Unclassified"),
    MainBase        UMETA(DisplayName = "Main Base"),
    NatExpansion    UMETA(DisplayName = "Natural Expansion"),
    ContestedExp    UMETA(DisplayName = "Contested Expansion"),
    ChokePoint      UMETA(DisplayName = "Choke Point"),
    OpenBattlefield UMETA(DisplayName = "Open Battlefield"),
    HighGround      UMETA(DisplayName = "High Ground"),
    FlankRoute      UMETA(DisplayName = "Flank Route"),
    VisionControl   UMETA(DisplayName = "Vision Control"),
    ResourceCluster UMETA(DisplayName = "Resource Cluster"),
};
```

### FRTSGrid — The Map Container
```cpp
struct FRTSGrid
{
    int32               Width;
    int32               Height;
    float               CellSize;       // world units per cell
    TArray<FRTSCell>    Cells;          // flat array: [Y * Width + X]

    // Fast access
    FORCEINLINE FRTSCell& GetCell(int32 X, int32 Y)
        { return Cells[Y * Width + X]; }

    FORCEINLINE int32 ToIndex(int32 X, int32 Y) const
        { return Y * Width + X; }

    FORCEINLINE FIntPoint ToCoord(int32 Index) const
        { return FIntPoint(Index % Width, Index / Width); }

    // Neighbor lookup (4-dir or 8-dir)
    TArray<int32> GetNeighbors(int32 Index, bool bDiagonal = false) const;
};
```

### URTSBiomeAsset — Data Asset (Blueprint Editable)
```cpp
UCLASS(BlueprintType)
class URTSBiomeAsset : public UDataAsset
{
    GENERATED_BODY()
public:
    UPROPERTY(EditAnywhere) FName       BiomeName;
    UPROPERTY(EditAnywhere) FLinearColor DebugColor;

    // Terrain rules
    UPROPERTY(EditAnywhere) float       HeightBias;         // push terrain up/down
    UPROPERTY(EditAnywhere) float       RoughnessMultiplier;
    UPROPERTY(EditAnywhere) float       CliffThreshold;

    // Traversal rules
    UPROPERTY(EditAnywhere) float       BaseMovementCost;   // 1.0 = normal
    UPROPERTY(EditAnywhere) bool        bAllowBuilding;

    // Resource rules
    UPROPERTY(EditAnywhere) float       ResourceDensity;
    UPROPERTY(EditAnywhere) TArray<FName> AllowedResources;

    // Visual rules (for future mesh placement)
    UPROPERTY(EditAnywhere) TArray<UStaticMesh*> PropMeshes;
    UPROPERTY(EditAnywhere) float               PropDensity;
};
```

### URTSGenerationSettings — The Config Object
```cpp
UCLASS(BlueprintType, Config=RTSMapForge)
class URTSGenerationSettings : public UDataAsset
{
    GENERATED_BODY()
public:
    // === MAP SIZE ===
    UPROPERTY(EditAnywhere, Category="Map") int32  GridWidth  = 256;
    UPROPERTY(EditAnywhere, Category="Map") int32  GridHeight = 256;
    UPROPERTY(EditAnywhere, Category="Map") float  CellSize   = 200.f; // cm

    // === SEED ===
    UPROPERTY(EditAnywhere, Category="Seed") int64  Seed        = 0;
    UPROPERTY(EditAnywhere, Category="Seed") bool   bRandomSeed = true;

    // === TERRAIN ===
    UPROPERTY(EditAnywhere, Category="Terrain") float  FBMOctaves       = 6;
    UPROPERTY(EditAnywhere, Category="Terrain") float  FBMPersistence   = 0.5f;
    UPROPERTY(EditAnywhere, Category="Terrain") float  FBMLacunarity    = 2.0f;
    UPROPERTY(EditAnywhere, Category="Terrain") float  TerrainScale     = 1.0f;
    UPROPERTY(EditAnywhere, Category="Terrain") float  WaterLevel       = 0.25f;
    UPROPERTY(EditAnywhere, Category="Terrain") float  MountainLevel    = 0.75f;

    // === STRATEGIC ===
    UPROPERTY(EditAnywhere, Category="Strategic") int32 NumPlayers      = 2;
    UPROPERTY(EditAnywhere, Category="Strategic") float MinRushDistance = 0.35f; // fraction of map diagonal
    UPROPERTY(EditAnywhere, Category="Strategic") float SymmetryStrength= 1.0f;  // 0=none, 1=full
    UPROPERTY(EditAnywhere, Category="Strategic") int32 NumExpansions   = 3;

    // === BIOMES ===
    UPROPERTY(EditAnywhere, Category="Biomes") TArray<URTSBiomeAsset*> Biomes;

    // === VALIDATION RULES ===
    UPROPERTY(EditAnywhere, Category="Validation") float MinChokeWidth     = 3.f;  // cells
    UPROPERTY(EditAnywhere, Category="Validation") float MaxChokeWidth     = 12.f;
    UPROPERTY(EditAnywhere, Category="Validation") float MinBuildableRatio = 0.25f;
    UPROPERTY(EditAnywhere, Category="Validation") float MaxFairnessError  = 0.10f; // 10%
};
```

---

## PART 4 — GENERATION PIPELINE (Full Design)

### Pipeline Execution Model
The pipeline is **sequential with dependency enforcement**. Each stage produces output data consumed by the next. Stages run asynchronously on a background thread, reporting progress to the editor.

```
[Seed Init] → [Grid Alloc] → [Noise Gen] → [Height Map] → [Water/Cliff]
    → [Biome Assignment] → [Region Detection] → [River Generation]
    → [Base Placement] → [Expansion Placement] → [Resource Placement]
    → [Choke Detection] → [Tactical Zone Classification]
    → [Pathfinding Graph] → [Influence Maps] → [Heatmap Generation]
    → [Strategic Scoring] → [Fairness Analysis] → [Validation]
    → [Metadata Baking] → [Complete]
```

### Stage-by-Stage Design

#### STAGE 1 — Seed Initialization
```
Input:  URTSGenerationSettings
Output: Deterministic FRandomStream

Algorithm:
  if bRandomSeed → Seed = FMath::Rand()
  Stream = FRandomStream(Seed)
  // ALL subsequent random calls use ONLY this stream
  // This guarantees: same seed + same settings = identical map
```

#### STAGE 2 — Grid Allocation
```
Input:  Width, Height, CellSize
Output: FRTSGrid (allocated, zero-initialized)

Notes:
  256×256 grid = 65,536 cells
  512×512 grid = 262,144 cells
  Each FRTSCell ≈ 128 bytes → 512×512 ≈ 32MB
  Use chunked allocation for >512×512
```

#### STAGE 3 — Heightmap Generation (FBM Noise)
```
Input:  FRTSGrid, FRandomStream, Terrain settings
Output: Grid.Cells[i].Height filled

Algorithm: Fractal Brownian Motion
  For each cell (x, y):
    float nx = x / Width  * TerrainScale;
    float ny = y / Height * TerrainScale;
    float h = 0.0f;
    float amplitude = 1.0f;
    float frequency = 1.0f;
    float maxVal = 0.0f;

    for (int o = 0; o < Octaves; o++):
      h += amplitude * PerlinNoise(nx * frequency + offsetX,
                                    ny * frequency + offsetY);
      maxVal += amplitude;
      amplitude *= Persistence;
      frequency *= Lacunarity;

    Cell.Height = h / maxVal;  // normalize 0..1

  // Apply falloff map for island-style (optional):
  Cell.Height -= FalloffMap[x][y];
  Cell.Height = FMath::Clamp(Cell.Height, 0.f, 1.f);
```

#### STAGE 4 — Terrain Classification
```
For each cell:
  if Height < WaterLevel   → bWater = true, bWalkable = false
  if Slope > CliffThreshold → bCliff = true, bWalkable = false
  else → bWalkable = true, bBuildable = (Slope < BuildThreshold)
```

#### STAGE 5 — Biome Assignment (Voronoi)
```
Input:  Grid with heights, Biome list
Output: Cell.BiomeID

Algorithm:
  Generate N Voronoi seed points (one per biome) using Poisson Disk Sampling
  For each cell:
    find nearest Voronoi seed
    assign BiomeID
    apply BiomeAsset terrain modifiers (HeightBias, RoughnessMultiplier)
```

#### STAGE 6 — Region Detection (Flood Fill)
```
Input:  Grid (walkability set)
Output: Cell.RegionID, list of FRTSRegion

Algorithm:
  BFS flood fill from unvisited walkable cells
  Each connected component = one region
  Store region: {CellCount, BoundingBox, CentroidCell}
  Filter: regions smaller than MinRegionSize are reclassified as obstacles
```

#### STAGE 7 — River Generation
```
Input:  Grid with heights
Output: River cells marked as water, terrain carved

Algorithm:
  1. Find mountain cells (Height > MountainLevel)
  2. Pick N river source points
  3. Gradient descent from source toward water level:
     next_cell = neighbor with lowest height
     mark as river, lower height slightly (erosion)
  4. Stop when reaching existing water or map edge
```

#### STAGE 8 — Base Placement
```
Input:  Grid, NumPlayers, MinRushDistance, SymmetryStrength
Output: Base positions per player

Algorithm:
  1. Collect candidate cells: large flat buildable regions far from map edges
  2. For player 1: pick candidate maximizing distance from all edges
  3. For player 2+: use rotational symmetry (180° for 2p, 120° for 3p, etc.)
     OR Poisson Disk minimum rush distance constraint
  4. Verify: A* rush distance between all bases >= MinRushDistance * MapDiagonal
  5. If constraint fails: retry with new candidates (max 50 retries)
```

#### STAGE 9 — Expansion Placement
```
Input:  Grid, base positions, NumExpansions
Output: Expansion positions with risk classification

For each base:
  Natural Expansion: closest large flat region outside base, within 30% map diagonal
  Risky Expansion:   mid-map region contested between players
  Third Expansion:   farther from base, lower protection

Risk score = (distance to nearest enemy base) / (distance to own base)
```

#### STAGE 10 — Choke Point Detection
```
Input:  Grid regions
Output: List of FRTSChoke{Width, CellList, ConnectedRegions}

Algorithm:
  1. Build adjacency graph between regions
  2. For each region boundary:
     BFS perpendicular to boundary direction
     Measure width = number of walkable cells in traversal band
  3. If width < MaxChokeWidth → classify as choke
  4. Classify: width 1-3 = hard choke, 4-8 = soft choke, 9+ = open passage
```

#### STAGE 11 — Tactical Zone Classification
```
For each cell, combine:
  - Distance to nearest base → base proximity
  - RegionID → which region
  - ChokeID → choke membership
  - Height → elevation class
  - ResourceValue → economy weight

Decision tree:
  IF in base region → MainBase
  IF natural expansion region → NatExpansion
  IF choke cell → ChokePoint
  IF Height > HighGroundThreshold AND neighbors lower → HighGround
  IF ResourceValue high AND contested → ResourceCluster
  IF thin corridor between regions → FlankRoute
  ELSE → OpenBattlefield or Unclassified
```

#### STAGE 12 — Pathfinding Graph (A*)
```
Input:  Grid (walkability + movement costs)
Output: A* ready graph; rush distances computed

A* heuristic: Octile distance (for 8-directional)
  h(n) = max(|dx|, |dy|) + (sqrt(2)-1) * min(|dx|, |dy|)

f(n) = g(n) + h(n)
g(n) = accumulated movement cost

Rush distance: run A* from each base to each other base
Store in FRTSStrategicMetrics.RushDistances[PlayerA][PlayerB]
```

#### STAGE 13 — Influence Maps
```
Algorithm:
  For each base B at position P with strength S:
  For each cell C:
    d = distance(P, C)
    Influence[C] += S / (d * d + 1)   // inverse square law

  Normalize to 0..1
  Compute ControlValue = argmax(player influence at cell)
```

#### STAGE 14 — Heatmap Generation
```
Heatmaps are float arrays of size [Width × Height]:
  - CombatHeatmap:     high where influence maps overlap (contested)
  - TraversalHeatmap:  high along A* paths between bases
  - BuildabilityMap:   bBuildable converted to float
  - ResourceHeatmap:   ResourceValue per cell
  - VisibilityHeatmap: VisibilityScore per cell
```

#### STAGE 15 — Strategic Scoring
```
struct FRTSStrategicMetrics
{
    float BalanceScore;        // 0-100: how fair are spawns?
    float RushDistanceScore;   // 0-100: is rush viable but not instant?
    float ExpansionSafety;     // 0-100: how well protected are naturals?
    float ChokeQuality;        // 0-100: good choke structure?
    float PathDiversity;       // 0-100: multiple routes between bases?
    float TerrainReadability;  // 0-100: is strategic layout clear?
    float OverallScore;        // weighted average
};

BalanceScore formula:
  For each pair of players (A, B):
    delta = |Resources(A) - Resources(B)| / max(Resources(A), Resources(B))
    BalanceScore -= delta * 100

PathDiversity:
  Count distinct paths (non-overlapping) from base A to base B via BFS
  Score = min(pathCount / 3, 1.0) * 100  // 3+ paths = 100
```

#### STAGE 16 — Validation Pipeline
```
ValidationPipeline runs all checks:

Pass 1 — Traversal:    All regions reachable from all bases?
Pass 2 — Spawn:        All bases have adequate flat buildable area?
Pass 3 — Economy:      Resource fairness within MaxFairnessError?
Pass 4 — Choke:        At least 1 choke per player pair?
Pass 5 — Navmesh:      Minimum traversal width >= MinChokeWidth?
Pass 6 — Fairness:     OverallScore >= MinAcceptableScore (default: 65)?

On failure:
  Record FRTSValidationResult{PassName, Reason, Severity}
  If Severity == Critical → reject map, retry generation
  If Severity == Warning  → accept but flag to user
```

---

## PART 5 — THREADING PLAN

```
[Game Thread / Editor Thread]
    ↓ Launch async task
    ↓
[UE Task System — Background Thread]
    Stage 1-3: Noise, Heightmap            (pure compute, no UObject access)
    Stage 4-7: Classification, Biomes      (pure compute)
    Stage 8-11: Strategic placement        (pure compute)
    Stage 12-14: Pathfinding, Heatmaps     (pure compute)
    Stage 15-16: Scoring, Validation       (pure compute)
    ↓ Return to Game Thread
[Game Thread]
    Stage 17: Metadata baking (UObject writes, Actor spawning)
    Stage 18: Debug overlay refresh (render thread interaction)

Implementation:
  UE::Tasks::Launch(TEXT("RTSMapGen"), [this]()
  {
      RunGenerationPipeline();
  }, UE::Tasks::ETaskPriority::BackgroundNormal);
```

---

## PART 6 — EDITOR MODULE (Slate UI)

### Generation Window (SRTSMapGeneratorWindow)
```
┌─────────────────────────────────────────────────────┐
│  RTSMapForge — Battlefield Generator          [?][X] │
├─────────────────┬───────────────────────────────────┤
│  SETTINGS       │         MINIMAP PREVIEW            │
│  ─────────────  │  ┌─────────────────────────────┐  │
│  Preset: [▼]    │  │                             │  │
│  Seed: [______] │  │    [live minimap render]    │  │
│  [🎲 Random]    │  │                             │  │
│                 │  └─────────────────────────────┘  │
│  Map Size       │                                   │
│  W: [256▲▼]     │  Overlay: [None ▼]                │
│  H: [256▲▼]     │  ○ Height  ○ Chokes  ○ Influence │
│                 │  ○ Combat  ○ Builds  ○ Resources  │
│  Players: [2▲▼] │                                   │
│  Symmetry:[1.0] │  Strategic Score: [███████░░] 71  │
│  Expansions:[3] │  Balance:         [████████░] 84  │
│                 │  Rush Distance:   [██████░░░] 62  │
│  [BIOMES ▼]     │  Path Diversity:  [███████░░] 76  │
│  [TERRAIN ▼]    │                                   │
│  [VALIDATION ▼] ├───────────────────────────────────┤
│                 │  Validation: ✅ 6/6 Passed         │
│  [GENERATE]     │  ⚠️  Narrow choke at (128, 95)    │
│  [SAVE PRESET]  │                                   │
│  [EXPORT MAP]   │  [APPLY TO LEVEL]  [BAKE NAVMESH] │
└─────────────────┴───────────────────────────────────┘
```

### Debug Overlay System
The overlay renders via `FPrimitiveDrawInterface` in editor viewport:
- Each heatmap = one pass: sample Cell.Value → lerp color → draw quad at WorldPosition
- Overlays are Material Instances on a flat mesh grid for performance
- Toggle via toolbar button added to Level Editor

---

## PART 7 — API DESIGN (What Blueprint Users See)

```cpp
// The main Blueprint-callable interface
UCLASS(BlueprintType)
class URTSMapForgeSubsystem : public UEditorSubsystem
{
public:
    // Generate a map with settings
    UFUNCTION(BlueprintCallable)
    void GenerateMap(URTSGenerationSettings* Settings,
                     FOnMapGenComplete OnComplete);

    // Query cell data
    UFUNCTION(BlueprintCallable, BlueprintPure)
    FRTSCell GetCellAtWorldLocation(FVector WorldLocation) const;

    UFUNCTION(BlueprintCallable, BlueprintPure)
    ERTSTacticalZone GetZoneAtLocation(FVector Location) const;

    // Strategic data
    UFUNCTION(BlueprintCallable, BlueprintPure)
    FRTSStrategicMetrics GetMapMetrics() const;

    // Heatmap query
    UFUNCTION(BlueprintCallable, BlueprintPure)
    float GetCombatHeatAt(FVector Location) const;

    // Export
    UFUNCTION(BlueprintCallable)
    void ExportMetadataToJSON(FString FilePath) const;

    UFUNCTION(BlueprintCallable)
    void BakeToLevel();
};
```

---

## PART 8 — DEVELOPMENT ORDER (Fastest Path to Sellable V1)

### Milestone 0 — Skeleton (Week 1–2)
- [ ] Plugin module structure (Runtime + Editor)
- [ ] FRTSGrid, FRTSCell structs
- [ ] FRTSSeedManager (deterministic FRandomStream)
- [ ] URTSGenerationSettings Data Asset
- [ ] Debug renderer (draw colored cells in editor viewport)
- **Goal:** Can create a grid, visualize it, save/load seed

### Milestone 1 — Terrain (Week 3–4)
- [ ] FBM Perlin noise heightmap
- [ ] Water / cliff classification
- [ ] Flood fill regions
- [ ] Basic biome assignment (Voronoi)
- **Goal:** Generates terrain, visualizes height + regions

### Milestone 2 — Strategic Core (Week 5–7)
- [ ] Base placement (Poisson Disk + symmetry)
- [ ] Expansion placement (risk classification)
- [ ] Choke point detection (width analysis)
- [ ] Tactical zone classification
- [ ] A* pathfinding + rush distance
- **Goal:** Places bases, finds chokes, computes rush distance — THIS is your demo video

### Milestone 3 — Analysis (Week 8–9)
- [ ] Influence maps
- [ ] Heatmap system (combat, traversal, buildability)
- [ ] Strategic scoring (FRTSStrategicMetrics)
- [ ] Fairness analyzer
- **Goal:** Scores maps; rejects bad maps automatically

### Milestone 4 — Validation + Editor UI (Week 10–12)
- [ ] Full validation pipeline
- [ ] Slate generation window
- [ ] Minimap preview
- [ ] Heatmap overlays in editor
- [ ] Preset save/load
- **Goal:** Polished editor workflow — this is what you sell

### Milestone 5 — Polish + Marketplace Prep
- [ ] Default biome assets (Temperate, Desert, Snow, Lava)
- [ ] Default presets (2p Competitive, 4p FFA, Defensive, Aggressive)
- [ ] Quick Start documentation
- [ ] API documentation
- [ ] Example project (standalone UE project)
- [ ] Demo video
- **Goal:** Submit to Fab

---

## PART 9 — PRICING & MARKET STRATEGY

| Phase | Version | Price | Features |
|---|---|---|---|
| Launch | V1.0 | **$149** | Core generator + strategic analysis + editor UI |
| 3 months | V1.5 | **$179** | River system + biome packs + presets |
| 6 months | V2.0 | **$249** | AI simulation + auto-balancing + metadata export |
| 12 months | V3.0 | **$399** | Runtime generation + campaign tools |

**Why start at $149 not $500:**
The RTSUnitTemplate reference sells for ~$49. An unknown plugin at $500 with zero reviews will not sell. At $149 with strong demo videos and 10 reviews, you can command premium prices on V2+. Build reputation first.

**Bundle strategy:** Partner with RTSUnitTemplate — joint bundle. Their customers are your customers.

---

## PART 10 — KNOWN RISKS & MITIGATIONS

| Risk | Severity | Mitigation |
|---|---|---|
| UE PCG API changes break integration | High | Do NOT depend on PCG in V1; wrap it in an optional adapter in V2 |
| Determinism bugs cause map desyncs | Critical | ALL random calls go through single FRandomStream; unit test seed reproducibility |
| Editor module shipped in runtime build | Critical | Strict module separation; Editor module uses `#if WITH_EDITOR` guards everywhere |
| Performance on large maps (512×512) | High | Async generation mandatory; add chunking for >256×256 |
| Fab certification rejection | Medium | Study submission checklist; no editor-only code in runtime; proper module declarations |
| Competition from PCG Framework | Medium | Your value is strategic analysis, not terrain — PCG cannot do choke detection or fairness scoring |

---

## APPENDIX — KEY FORMULAS REFERENCE

```
FBM:          h = Σ(amplitude_i * noise(freq_i * x, freq_i * y)) / Σ(amplitude_i)
Slope:        θ = arctan(Δh / Δd)
A*:           f(n) = g(n) + h(n),  h = octile distance
Influence:    I(x,y) = Σ(strength_i / (dist(x,y, base_i)² + 1))
Fitness:      F = α*Balance + β*Diversity + γ*StrategicDepth
Balance err:  δ = |Resources_A - Resources_B| / max(Resources_A, Resources_B)
Rush viable:  RushDist >= MinRushFraction * MapDiagonal
```
