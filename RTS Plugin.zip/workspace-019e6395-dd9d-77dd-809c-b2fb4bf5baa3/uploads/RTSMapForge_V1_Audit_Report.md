# RTSMapForge V1 Audit Report

Scope: Unreal Engine 5 procedural RTS battlefield generation plugin audit for production readiness and Fab Marketplace quality.

Overall verdict: not release-ready yet. The codebase has one hard compile blocker, one major landscape baking false-positive, and several determinism and lifecycle issues that will undermine repeatability, editor stability, and reviewer confidence.

## Critical Issues

1. Compile blocker in river source selection.
   - [Source/RTSMapForgeRuntime/Private/Terrain/FRTSRiverGenerator.cpp](Source/RTSMapForgeRuntime/Private/Terrain/FRTSRiverGenerator.cpp) uses `Peaks` inside a lambda passed to `Indices.Sort(...)` without capturing it. That code cannot compile as written and will block the plugin from building.

2. Landscape baking reports success without actually importing height data.
   - [Source/RTSMapForgeRuntime/Private/Terrain/FRTSLandscapeBaker.cpp](Source/RTSMapForgeRuntime/Private/Terrain/FRTSLandscapeBaker.cpp) prepares a height buffer, logs success, and returns `true`, but the actual import into `ALandscapeProxy` is not implemented. This is a functional no-op disguised as a successful bake.

3. Seed determinism is unstable across the generation pipeline.
   - [Source/RTSMapForgeRuntime/Private/Core/URTSGenerationSettings.cpp](Source/RTSMapForgeRuntime/Private/Core/URTSGenerationSettings.cpp) resolves random seeds by calling `FMath::Rand()` multiple times.
   - [Source/RTSMapForgeRuntime/Private/Core/FRTSGenerationPipeline.cpp](Source/RTSMapForgeRuntime/Private/Core/FRTSGenerationPipeline.cpp) calls `ResolveSeed()` repeatedly across stages.
   - [Source/RTSMapForgeEditor/Private/URTSMapForgeEditorSubsystem.cpp](Source/RTSMapForgeEditor/Private/URTSMapForgeEditorSubsystem.cpp) records `LastMetadata.Seed` after generation using another `ResolveSeed()` call.
   Together, these paths can produce different seeds inside one generation, which breaks reproducibility, replayability, and validation trust.

4. Rooted UObject lifetime is not cleaned up.
   - [Source/RTSMapForgeRuntime/Private/Core/FRTSGenerationPipeline.cpp](Source/RTSMapForgeRuntime/Private/Core/FRTSGenerationPipeline.cpp) creates `UFRTSSeedManager` and calls `AddToRoot()` in the constructor, but there is no matching `RemoveFromRoot()` in teardown.
   - This leaks a rooted object for the remainder of the session and is especially poor behavior for editor tooling that may create multiple pipeline instances.

5. Landscape bake API surface promises more than the implementation delivers.
   - [Source/RTSMapForgeRuntime/Private/Terrain/FRTSLandscapeBaker.cpp](Source/RTSMapForgeRuntime/Private/Terrain/FRTSLandscapeBaker.cpp) is presented as the bake path, but the actual Landscape import is still deferred with a TODO-style placeholder.
   - For a marketplace product, that is a product gap, not just a technical debt item.

## Warnings

1. Editor overlay subsystem leaks rooted preview textures.
   - [Source/RTSMapForgeEditor/Private/URTSMapForgeEditorSubsystem.cpp](Source/RTSMapForgeEditor/Private/URTSMapForgeEditorSubsystem.cpp) calls `AddToRoot()` when creating `PreviewTexture`, but `Deinitialize()` only calls `MarkAsGarbage()` and clears the pointer. That leaves the object rooted and prevents normal cleanup.

2. Editor shutdown removes unrelated toolbar extenders.
   - [Source/RTSMapForgeEditor/Private/RTSMapForgeEditorModule.cpp](Source/RTSMapForgeEditor/Private/RTSMapForgeEditorModule.cpp) calls `RemoveAllExtenders()` on the Level Editor toolbar manager during shutdown. That is too broad and can remove extenders owned by other plugins.

3. Validation path relies on assumptions that are not enforced defensively.
   - [Source/RTSMapForgeRuntime/Private/Validation/FRTSValidationPipeline.cpp](Source/RTSMapForgeRuntime/Private/Validation/FRTSValidationPipeline.cpp) dereferences `Settings` throughout the pass pipeline without validating it inside each pass.
   - The current call path may be safe, but the public API is fragile if reused elsewhere.

4. Resource accessibility scoring does not follow the actual path.
   - [Source/RTSMapForgeRuntime/Private/Validation/FRTSResourceAccessibilityValidator.cpp](Source/RTSMapForgeRuntime/Private/Validation/FRTSResourceAccessibilityValidator.cpp) traces a Bresenham line between points and counts chokes/crossings along that straight line, rather than evaluating the actual route found by A*.
   - That can mis-score reachability and safety on curved or terrain-constrained maps.

5. Memory profiler output is inflated.
   - [Source/RTSMapForgeRuntime/Private/Core/FRTSGrid.cpp](Source/RTSMapForgeRuntime/Private/Core/FRTSGrid.cpp) reports `Cells.GetAllocatedSize()` and then adds `Cells.Num() * sizeof(FRTSCell)` again, double-counting the cell array.
   - [Source/RTSMapForgeRuntime/Private/Core/FRTSMemoryProfiler.cpp](Source/RTSMapForgeRuntime/Private/Core/FRTSMemoryProfiler.cpp) then builds release-readiness expectations on that biased number.

6. No infinite retry loop was found, but retry behavior still mutates global state.
   - [Source/RTSMapForgeRuntime/Private/Core/FRTSGenerationPipeline.cpp](Source/RTSMapForgeRuntime/Private/Core/FRTSGenerationPipeline.cpp) caps retries with `for (Retry < MaxRetries)`, so I did not find an unbounded loop.
   - The concern is state mutation across retries, not livelock.

## Performance Risks

1. A* implementation is linear-search based.
   - [Source/RTSMapForgeRuntime/Private/Pathfinding/FRTSAStarSolver.cpp](Source/RTSMapForgeRuntime/Private/Pathfinding/FRTSAStarSolver.cpp) scans the full open set to find the best node and scans it again to update membership.
   - This is acceptable for small maps, but it scales poorly for large grids and repeated validation calls.

2. Validation cost grows quickly with player count and resource density.
   - [Source/RTSMapForgeRuntime/Private/Validation/FRTSValidationPipeline.cpp](Source/RTSMapForgeRuntime/Private/Validation/FRTSValidationPipeline.cpp) performs pairwise base reachability checks.
   - [Source/RTSMapForgeRuntime/Private/Validation/FRTSResourceAccessibilityValidator.cpp](Source/RTSMapForgeRuntime/Private/Validation/FRTSResourceAccessibilityValidator.cpp) then runs pathfinding per resource and additional tracing work per resource.

3. Overlay rendering is immediate-mode and per-cell.
   - [Source/RTSMapForgeRuntime/Private/Visualization/FRTSDebugRenderer.cpp](Source/RTSMapForgeRuntime/Private/Visualization/FRTSDebugRenderer.cpp) issues four `DrawLine` calls for every cell in the viewport overlay.
   - That is a heavy editor-time workload for large maps and will become a bottleneck well before runtime generation does.

4. Preview texture updates rebuild the full bitmap every time.
   - [Source/RTSMapForgeEditor/Private/URTSMapForgeEditorSubsystem.cpp](Source/RTSMapForgeEditor/Private/URTSMapForgeEditorSubsystem.cpp) regenerates the full minimap image and uploads the entire texture on each overlay change.
   - This is fine for small grids, but it will feel expensive on dense or repeated editor interactions.

5. Prop spawning is not yet scalable for dense content sets.
   - [Source/RTSMapForgeRuntime/Private/Spawning/URTSPropSpawner.cpp](Source/RTSMapForgeRuntime/Private/Spawning/URTSPropSpawner.cpp) adds instances one by one and uses one HISM component per mesh.
   - The current implementation is functional for light use, but repeated clears, high mesh counts, or large maps will need batching and lifecycle cleanup.

6. Terrain slope scaling may flatten strategic differences.
   - [Source/RTSMapForgeRuntime/Private/Terrain/FRTSHeightmapGenerator.cpp](Source/RTSMapForgeRuntime/Private/Terrain/FRTSHeightmapGenerator.cpp) divides normalized height gradients by cell size when computing slope.
   - On typical grid sizes this can make slope-based walkability and buildability thresholds less discriminating than intended.

## UE Marketplace Risks

1. Plugin metadata is still placeholder-level.
   - [RTSMapForge.uplugin](RTSMapForge.uplugin) has empty `DocsURL`, `MarketplaceURL`, and `SupportURL` fields and a placeholder `CreatedBy` value.
   - Fab reviewers expect a cleaner public-facing package identity.

2. Runtime/editor boundaries are blurred by editor-only functionality living in runtime code.
   - [Source/RTSMapForgeRuntime/Private/Terrain/FRTSLandscapeBaker.cpp](Source/RTSMapForgeRuntime/Private/Terrain/FRTSLandscapeBaker.cpp) is compiled in the runtime module but is conceptually an editor-only workflow.
   - Even with `WITH_EDITOR` guards, this is a common source of packaging confusion and version-specific breakage.

3. Module dependency risk needs version verification.
   - [Source/RTSMapForgeRuntime/RTSMapForgeRuntime.Build.cs](Source/RTSMapForgeRuntime/RTSMapForgeRuntime.Build.cs) depends on `InstancedPlacements` and conditionally references editor modules from the runtime module.
   - Verify those modules exist and remain stable across the target UE versions, or packaging and distribution can fail unexpectedly.

4. Editor module shutdown behavior is not polite enough for a shared ecosystem.
   - [Source/RTSMapForgeEditor/Private/RTSMapForgeEditorModule.cpp](Source/RTSMapForgeEditor/Private/RTSMapForgeEditorModule.cpp) modifies global toolbar extender state too aggressively.
   - Marketplace plugins should avoid removing editor state they do not own.

5. Some currently exposed features read like placeholders.
   - [Source/RTSMapForgeRuntime/Private/Spawning/URTSPropSpawner.cpp](Source/RTSMapForgeRuntime/Private/Spawning/URTSPropSpawner.cpp) logs how many props would be placed, but the V1 path still does not actually spawn the prop set described in the comments.
   - That is risky for customer expectations and review quality.

## Recommended Fixes

1. Fix the compile blocker in river source sorting immediately.
   - Replace the lambda in [Source/RTSMapForgeRuntime/Private/Terrain/FRTSRiverGenerator.cpp](Source/RTSMapForgeRuntime/Private/Terrain/FRTSRiverGenerator.cpp) with a comparator that captures or otherwise accesses the peak array safely.

2. Make seed resolution single-source and deterministic.
   - Resolve the seed once at the start of generation and pass that value through the pipeline.
   - Replace repeated `ResolveSeed()` calls in [Source/RTSMapForgeRuntime/Private/Core/FRTSGenerationPipeline.cpp](Source/RTSMapForgeRuntime/Private/Core/FRTSGenerationPipeline.cpp), [Source/RTSMapForgeRuntime/Private/Terrain/FRTSHeightmapGenerator.cpp](Source/RTSMapForgeRuntime/Private/Terrain/FRTSHeightmapGenerator.cpp), and [Source/RTSMapForgeEditor/Private/URTSMapForgeEditorSubsystem.cpp](Source/RTSMapForgeEditor/Private/URTSMapForgeEditorSubsystem.cpp) with a stored generation seed.

3. Unroot or otherwise own UObject lifetimes correctly.
   - Add a teardown path for the rooted `UFRTSSeedManager` in [Source/RTSMapForgeRuntime/Private/Core/FRTSGenerationPipeline.cpp](Source/RTSMapForgeRuntime/Private/Core/FRTSGenerationPipeline.cpp).
   - Remove the preview texture from the root set before discarding it in [Source/RTSMapForgeEditor/Private/URTSMapForgeEditorSubsystem.cpp](Source/RTSMapForgeEditor/Private/URTSMapForgeEditorSubsystem.cpp).

4. Complete the landscape bake implementation or explicitly scope it out.
   - If the plugin claims landscape baking, make [Source/RTSMapForgeRuntime/Private/Terrain/FRTSLandscapeBaker.cpp](Source/RTSMapForgeRuntime/Private/Terrain/FRTSLandscapeBaker.cpp) perform a real import path for the target UE version.
   - If not, downgrade the feature to a documented experimental/editor utility so it does not read as a false shipping feature.

5. Rework prop spawning for actual content creation and cleanup.
   - Ensure [Source/RTSMapForgeRuntime/Private/Spawning/URTSPropSpawner.cpp](Source/RTSMapForgeRuntime/Private/Spawning/URTSPropSpawner.cpp) actually creates the intended instances, destroys or reuses components on clear, and batches instance insertion where possible.

6. Replace the linear A* open set with a heap or priority queue.
   - This will reduce validation and pathfinding cost on large maps and improve the worst-case behavior of [Source/RTSMapForgeRuntime/Private/Pathfinding/FRTSAStarSolver.cpp](Source/RTSMapForgeRuntime/Private/Pathfinding/FRTSAStarSolver.cpp).

7. Make overlay rendering cheaper for large maps.
   - Consider tile batching, cached mesh overlays, or an instanced debug visualization path instead of four draw calls per cell in [Source/RTSMapForgeRuntime/Private/Visualization/FRTSDebugRenderer.cpp](Source/RTSMapForgeRuntime/Private/Visualization/FRTSDebugRenderer.cpp).

8. Tighten editor-module shutdown behavior.
   - Remove only the extenders created by this plugin in [Source/RTSMapForgeEditor/Private/RTSMapForgeEditorModule.cpp](Source/RTSMapForgeEditor/Private/RTSMapForgeEditorModule.cpp).

9. Correct memory accounting before using profiler data for decisions.
   - Fix the double-count in [Source/RTSMapForgeRuntime/Private/Core/FRTSGrid.cpp](Source/RTSMapForgeRuntime/Private/Core/FRTSGrid.cpp) and then rebaseline [Source/RTSMapForgeRuntime/Private/Core/FRTSMemoryProfiler.cpp](Source/RTSMapForgeRuntime/Private/Core/FRTSMemoryProfiler.cpp).

10. Add targeted tests for the exact failure modes found here.
   - Add a compile-safe lambda test or static build check for river source selection.
   - Add determinism tests that assert the same seed is propagated through every stage.
   - Add an editor test that exercises preview texture creation and teardown without leaking rooted objects.

## Architecture Strengths

1. The plugin has the right high-level module split.
   - [RTSMapForge.uplugin](RTSMapForge.uplugin) separates `RTSMapForgeRuntime` from `RTSMapForgeEditor`, which is the correct UE plugin shape.

2. Core simulation data is stored in a cache-friendly flat grid.
   - [Source/RTSMapForgeRuntime/Private/Core/FRTSGrid.cpp](Source/RTSMapForgeRuntime/Private/Core/FRTSGrid.cpp) uses contiguous storage and fixed neighbor buffers, which is a sensible foundation for procedural generation.

3. The seed manager abstraction is a good design choice.
   - [Source/RTSMapForgeRuntime/Private/Core/FRTSSeedManager.cpp](Source/RTSMapForgeRuntime/Private/Core/FRTSSeedManager.cpp) centralizes deterministic random stream usage and is the right direction for replayable generation.

4. Validation is staged and explicit.
   - [Source/RTSMapForgeRuntime/Private/Validation/FRTSValidationPipeline.cpp](Source/RTSMapForgeRuntime/Private/Validation/FRTSValidationPipeline.cpp) keeps traversal, spawn, economy, choke, navmesh, and fairness checks separate, which makes the system easier to extend and audit.

5. The codebase already has determinism coverage.
   - [Source/RTSMapForgeRuntime/Private/Tests/RTSMapForgeDeterminismTests.cpp](Source/RTSMapForgeRuntime/Private/Tests/RTSMapForgeDeterminismTests.cpp) is a strong sign that the project is trying to enforce repeatability rather than assuming it.

6. Editor-facing previewing is integrated rather than bolted on.
   - [Source/RTSMapForgeEditor/Private/URTSMapForgeEditorSubsystem.cpp](Source/RTSMapForgeEditor/Private/URTSMapForgeEditorSubsystem.cpp) and [Source/RTSMapForgeRuntime/Private/Visualization/FRTSDebugRenderer.cpp](Source/RTSMapForgeRuntime/Private/Visualization/FRTSDebugRenderer.cpp) provide a clear path from generation data to visual inspection.

## Release Readiness Verdict

Not ready for Fab Marketplace release.

The main blockers are the river generator compile error, the landscape bake implementation that returns success without actually baking, and the nondeterministic seed flow that can change output within a single generation. Those issues are serious enough to undermine both build confidence and user trust.

If the top fixes are completed and validated, the plugin can move from prototype quality toward production quality. At that point, the most important remaining work is cleanup: proper UObject lifetime handling, better editor shutdown hygiene, stronger scaling for pathfinding and overlays, and clearer marketplace-facing metadata.